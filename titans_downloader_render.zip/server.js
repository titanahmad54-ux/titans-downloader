const express=require('express');
const axios=require('axios');
const app=express();
app.use(express.json());
app.use(express.static('public'));

async function extractTikTokVideo(url){
  const r=await axios.get(url,{maxRedirects:5,headers:{'User-Agent':'Mozilla/5.0 TITANS'}})
  const html=r.data;
  const m=html.match(/"playAddr":"(https:[^"]+)/);
  if(m) return m[1].replace(/\\u0026/g,'&').replace(/\\\//g,'/');
  return null;
}

app.post('/api/download',async(req,res)=>{
  const {url}=req.body||{};
  if(!url) return res.status(400).send('URL kosong');
  try{
    const v=await extractTikTokVideo(url);
    if(!v) return res.status(404).send('Video tidak ditemukan');
    res.json({videoUrl:v});
  }catch(e){
    res.status(500).send('Error: '+e.message);
  }
});

const PORT=process.env.PORT||3000;
app.listen(PORT,()=>console.log('Running on '+PORT));
